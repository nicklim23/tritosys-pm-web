

<?php $__env->startSection('customstyle'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
  <div class="row mt-4">
    <div class="col-12">
      <div class="row">
        <!-- Textual inputs start -->
        <div class="col-12 mt-5">
          <div class="card">
            <div class="card-body">
              <h4 class="header-title" style="font-size:24px;text-align:center;" >
                <b>Add Project</b>
              </h4>
              <form id="form1">
              <?php echo csrf_field(); ?>
                <div class="form-group row">
                    <div class="col-md-6">
                        <label for="name" class="col-form-label">
                            Project Name <b style="color:red;">*</b>
                        </label>
                        <input class="form-control" type="text" value="" id="name" name="name">
                    </div>
                    <div class="col-md-6">
                        <label for="customer_id" class="col-form-label">
                            Customer <b style="color:red;">*</b>
                        </label>
                        <select class="form-control" id="customer_id" name="customer_id">
                            <option value="" style="font-size:16px;">--Select Company--</option>
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($customer->id); ?>" style="font-size:16px;">
                                <?php echo e($customer->company_name); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-6">
                        <label for="site_id" class="col-form-label">
                            Site <b style="color:red;">*</b>
                        </label>
                        <select class="form-control" id="site_id" name="site_id">
                            <option value="" style="font-size:16px;">--Select Site--</option>
                            <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($site->id); ?>" style="font-size:16px;">
                                <?php echo e($site->name); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="project_manager" class="col-form-label">
                            Project Manager <b style="color:red;">*</b>
                        </label>
                        <input class="form-control" type="text" value="" id="project_manager" name="project_manager">
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-6">
                        <label for="date" class="col-form-label">
                            Date <b style="color:red;">*</b>
                        </label>
                        <input class="form-control" type="date" value="" id="date" name="date">
                    </div>
                    <div class="col-md-6">
                        <label for="status" class="col-form-label">
                            Status <b style="color:red;">*</b>
                        </label>
                        <select class="form-control" id="status" name="status">
                            <option value="" style="font-size:16px;">--Select Status--</option>
                            <option value="Active" style="font-size:16px;">
                              Active
                            </option>
                            <option value="Inactive" style="font-size:16px;">
                              Inactive
                            </option>
                        </select>
                    </div>
                </div>
                <br>
                <div style="text-align:center;">
                  <button class="btn bg-gradient-info lg-3" type="submit" role="button">Save</button>
                  <a class="btn bg-gradient-info lg-3" href="<?php echo e(url('/customers')); ?>" role="button">Back</a>
                </div>
              </form>
            </div>
          </div>
        </div>
        <!-- Textual inputs end -->
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagespecificscripts'); ?>
<script>
  /*---form1 submit---*/
  $.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
    });
  $('#form1').submit(function(e){

    e.preventDefault();
    console.log("hahaha")
    const swalCustomButtons = Swal.mixin({
        customClass: {
          confirmButton: 'btn bg-gradient-info',
        },
        buttonsStyling: false
      })
      // if form validation passed

          //submit to backend
          var formData = new FormData(this);

           $.ajax({
               url: "<?php echo e(url('projects')); ?>",
               type: "post",
               data: formData,
               processData: false,
               contentType: false,
              success: function (response) {
                 console.log("success");
                 swalCustomButtons.fire({
                        icon: 'success',
                        position: 'center',
                        type: 'success',
                        title: 'Data Add Successfully!',
                        showButton: true,
                    })
                    setTimeout(function(){
                        window.location = "/projects";
                    }, 1500);
              },
              error: function (error) {
                Swal.fire(
                        'Error!',
                        "Failed! Please try again.",
                        'error'
                    )
              }
          });
       }
   );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Codligence\Downloads\GitHub\tritosys-pm-web\resources\views/project/add_project.blade.php ENDPATH**/ ?>