

<?php $__env->startSection('customstyle'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row mt-4">
        <div class="col-12">
            <div class="card">
                <!-- Card header -->
                <div class="card-header">
                    <div class="row">
                        <div class="col-sm-6">
                            <h5 class="mb-0">Sites</h5>
                            <p class="text-sm mb-0">
                                Table list of sites.
                            </p>
                        </div>
                        <div class="col-sm-6" style="text-align:right;">
                            <a href="<?php echo e(url('sites/add')); ?>" role="button" class="btn bg-gradient-success">+ Add
                                Site</a>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-flush" id="datatable-search">
                        <thead class="thead-light">
                            <tr>
                                <th>Site ID</th>
                                <th>Site Name</th>
                                <th>Person In Charge</th>
                                <th>Address</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-sm font-weight-normal">
                                    <a class="ref-link" href="<?php echo e(url('sites')); ?>/<?php echo e($site->id); ?>"><?php echo e($site->site_id); ?></a>
                                </td>
                                <td class="text-sm font-weight-normal"><?php echo e($site->name); ?></td>
                                <td class="text-sm font-weight-normal"><?php echo e($site->person_in_charge); ?></td>
                                <td class="text-sm font-weight-normal"><?php echo e($site->address); ?></td>
                                <td class="text-sm">
                                    <a href="<?php echo e(url('sites')); ?>/<?php echo e($site->id); ?>" data-bs-toggle="tooltip" data-bs-original-title="More">
                                        <i class="fas fa-eye text-info" aria-hidden="true"></i>
                                    </a>
                                    <a data-route="<?php echo e(url('api/sites')); ?>/<?php echo e($site->id); ?>" onclick="removeData(this)" class="ms-3" data-bs-toggle="tooltip">
                                        <i class="fas fa-trash text-danger" aria-hidden="true"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagespecificscripts'); ?>
    <script>
        const dataTableSearch = new simpleDatatables.DataTable("#datatable-search", {
            searchable: true,
            fixedHeight: true
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Codligence\Downloads\GitHub\tritosys-pm-web\resources\views/site/listing.blade.php ENDPATH**/ ?>