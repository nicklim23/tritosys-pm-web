<!--
=========================================================
* Argon Dashboard 2 PRO - v2.0.2
=========================================================

* Product Page:  https://www.creative-tim.com/product/argon-dashboard-pro 
* Copyright 2022 Creative Tim (https://www.creative-tim.com)
* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
-->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('assets/img/logos/favicon.png')); ?>">
  <link rel="icon" type="image/png" href="<?php echo e(asset('assets/img/logos/favicon.png')); ?>">
  <title>
    TritoSys PM
  </title>
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
  <!-- Nucleo Icons -->
  <link href="<?php echo e(asset('assets/css/nucleo-icons.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('assets/css/nucleo-svg.css')); ?>" rel="stylesheet" />
  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
  <!-- CSS Files -->
  <link id="pagestyle" href="<?php echo e(asset('assets/css/argon-dashboard.css?v=2.0.2')); ?>" rel="stylesheet" />
</head>

<body class="">
  <main class="main-content main-content-bg mt-0">
    <div class="page-header min-vh-100">
      <span class="mask bg-gradient-dark opacity-6"></span>
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-5 col-md-7">
            <div class="card border-0 mb-0">
              <div class="card-header bg-transparent text-center">
                <img src="<?php echo e(asset('assets/img/logos/logo.png')); ?>" style="width: 80%" alt="main_logo">
              </div>
              <div class="card-body px-lg-5 pt-0">
                <div class="text-center text-muted mb-4">
                  <small>Welcome to TritoSys PM</small>
                </div>
                <form role="form" class="text-start" id="login_form" method="post" action="/login">
                  <?php echo csrf_field(); ?>
                  <div class="mb-3">
                    <input type="email" class="form-control" placeholder="Email" aria-label="Email" name="email">
                  </div>
                  <div class="mb-3">
                    <input type="password" class="form-control" placeholder="Password" aria-label="Password" name="password">
                  </div>
                  <div class="text-center">
                    <button type="submit" class="btn btn-primary w-100 mb-2">Sign In</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
  <!-- jQuery -->
  <script src="<?php echo e(asset('assets/js/jquery-1.7.1.min.js')); ?>"></script>
  <!--   Core JS Files   -->
  <script src="<?php echo e(asset('assets/js/core/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/core/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/plugins/perfect-scrollbar.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/plugins/smooth-scrollbar.min.js')); ?>"></script>
  <!-- Kanban scripts -->
  <script src="<?php echo e(asset('assets/js/plugins/dragula/dragula.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/plugins/jkanban/jkanban.js')); ?>"></script>
  <script>
    var win = navigator.platform.indexOf('Win') > -1;
    if (win && document.querySelector('#sidenav-scrollbar')) {
      var options = {
        damping: '0.5'
      }
      Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
    }
  </script>
  <!-- Github buttons -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!-- Control Center for Soft Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="<?php echo e(asset('assets/js/argon-dashboard.min.js?v=2.0.2')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/const.js')); ?>"></script>
    <?php if(session('status')=="failed"): ?>
    <script> 
    Swal.fire(
          'Error!',
          "Invalid email or password!",
          'error'
          )
    </script>
    <?php endif; ?>
  <script>
	// $('#login_form').submit(function(e){
	//     e.preventDefault();
  //     //console.log("test");
	//     //submit to backend
	//     var formData = new FormData(this);
	//     $.ajax({
	//         type: "POST",
	//         url: ROUTE.USER.LOGIN,
	//         data: formData,
	//         processData: false,
	//         contentType: false,
	//         success: function (response) {
	//             console.log(response);
	//             // window.location.href = DOMAIN + "/dashboard";
	//         },
	//         error: function (xhr,status,error){
	//             alert("Invalid email or password!")
	//             console.log(error);
	//         }
	//     });
	// });
	</script>

</body>

</html><?php /**PATH C:\Users\Codligence\Downloads\GitHub\tritosys-pm-web\resources\views/login.blade.php ENDPATH**/ ?>