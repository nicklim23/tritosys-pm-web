

<?php $__env->startSection('customstyle'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mt-4">
        <div class="col-12">
            <div class="multisteps-form mb-5">
                <!--progress bar-->
                <div class="row">
                    <div class="col-12 col-lg-12 mx-auto my-4">
                        <div class="card">
                            <div class="card-body">
                                <div class="multisteps-form__progress">
                                    <button class="multisteps-form__progress-btn js-active" type="button" title="Project Details">
                                        <span>Project Details</span>
                                    </button>
                                    <button class="multisteps-form__progress-btn" type="button" title="Materials">Materials</button>
                                    <button class="multisteps-form__progress-btn" type="button" title="Installation">Installation</button>
                                    <button class="multisteps-form__progress-btn" type="button" title="Installation">Acceptance</button>
                                    <button class="multisteps-form__progress-btn" type="button" title="Decomm Materials">Decomm Materials</button>
                                    <button class="multisteps-form__progress-btn" type="button" title="Installation">Documentation</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!--form panels-->
                <div class="row">
                    <div class="col-12 col-lg-12 m-auto">
                        <div class="multisteps-form__form mb-8">
                            
                            <!-- Project Details-->
                            <form id="project">
                                <?php echo csrf_field(); ?>
                                <div class="card multisteps-form__panel p-3 border-radius-xl bg-white js-active"
                                    data-animation="FadeIn">
                                    <div class="multisteps-form__content">
                                        <div class="form-group row">
                                            <div class="col-md-6">
                                                <label for="name" class="col-form-label">
                                                    Project Name <b style="color:red;">*</b>
                                                </label>
                                                <input class="form-control" type="text" value="<?php echo e($project->name); ?>"
                                                    id="name" name="name">
                                            </div>
                                            <div class="col-md-6">
                                                <label for="customer_id" class="col-form-label">
                                                    Customer <b style="color:red;">*</b>
                                                </label>
                                                <select class="form-control" id="customer_id" name="customer_id">
                                                    <option value="" style="font-size:16px;">--Select Company--
                                                    </option>
                                                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($customer->id); ?>" style="font-size:16px;" <?php echo e($project->customer_id == $customer->id ? 'selected' : ''); ?>>
                                                            <?php echo e($customer->company_name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-6">
                                                <label for="site_id" class="col-form-label">
                                                    Site <b style="color:red;">*</b>
                                                </label>
                                                <select class="form-control" id="site_id" name="site_id">
                                                    <option value="" style="font-size:16px;">--Select Site--
                                                    </option>
                                                    <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($site->id); ?>" style="font-size:16px;" <?php echo e($project->site_id == $site->id ? 'selected' : ''); ?>>
                                                            <?php echo e($site->name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="project_manager" class="col-form-label">
                                                    Project Manager <b style="color:red;">*</b>
                                                </label>
                                                <input class="form-control" type="text" value="<?php echo e($project->project_manager); ?>" id="project_manager" name="project_manager">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-6">
                                                <label for="date" class="col-form-label">
                                                    Date <b style="color:red;">*</b>
                                                </label>
                                                <input class="form-control" type="date" value="<?php echo e($project->date); ?>" id="date" name="date">
                                            </div>
                                            <div class="col-md-6">
                                                <label for="status" class="col-form-label">
                                                    Status <b style="color:red;">*</b>
                                                </label>
                                                <select class="form-control" id="status" name="status">
                                                    <option value="" style="font-size:16px;">--Select Status--
                                                    </option>
                                                    <option value="Active" style="font-size:16px;" <?php echo e($project->status == 'Active' ? 'selected' : ''); ?>>
                                                        Active
                                                    </option>
                                                    <option value="Inactive" style="font-size:16px;" <?php echo e($project->status == 'Inactive' ? 'selected' : ''); ?>>
                                                        Inactive
                                                    </option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="d-flex justify-content-end mt-4">
                                            <a class="btn bg-gradient-danger lg-3" href="<?php echo e(url('/projects')); ?>" role="button">Back</a>
                                            &ensp;
                                            <button class="btn bg-gradient-info lg-3 ms-2" type="submit" role="button">Save</button>
                                        </div>
                                    </div>
                                </div>
                            </form>

                            <!-- Materials -->
                            <div class="card multisteps-form__panel p-3 border-radius-xl bg-white"
                                data-animation="FadeIn">
                                <div class="multisteps-form__content">
                                    <div class="row mt-1">
                                        <div class="col-12" style="text-align: right">
                                            <a class="btn bg-gradient-success" href="#" data-bs-toggle="modal" data-bs-target="#materialModal">+ Add</a>
                                        </div>
                                        <div class="col-12">
                                            <div class="table-responsive">
                                                <table class="table table-flush" id="datatable-search">
                                                    <thead class="thead-light">
                                                        <tr>
                                                            <th>#</th>
                                                            <th>Collection Date</th>
                                                            <th>Collected By</th>
                                                            <th>Remarks</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($loop->index+1); ?></td>
                                                            <td><?php echo e($item->collection_date); ?></td>
                                                            <td><?php echo e($item->collected_by); ?></td>
                                                            <td><?php echo e($item->remarks); ?></td>
                                                            <td>
                                                                <a data-route="<?php echo e(url('projects/materials/'.$item->id)); ?>" data-csrf="<?php echo e(csrf_token()); ?>" onclick="removeData(this)" class="ms-3" data-bs-toggle="tooltip">
                                                                    <i class="fas fa-trash text-danger" aria-hidden="true"></i>
                                                                </a>
                                                            </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Installation -->
                            <div class="card multisteps-form__panel p-3 border-radius-xl bg-white"
                                data-animation="FadeIn">
                                <div class="multisteps-form__content">
                                    <div class="row mt-1">
                                        <div class="col-12" style="text-align: right">
                                            <a class="btn bg-gradient-success" href="#" data-bs-toggle="modal"
                                                data-bs-target="#installationModal">+ Add</a>
                                        </div>
                                        <div class="col-12">
                                            <div class="table-responsive">
                                                <table class="table table-flush" id="datatable-search2">
                                                    <thead class="thead-light">
                                                        <tr>
                                                            <th>#</th>
                                                            <th>Scope</th>
                                                            <th>Team Assigned</th>
                                                            <th>Start Date</th>
                                                            <th>Completed Date</th>
                                                            <th>Week Completion</th>
                                                            <th>Remarks</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $installations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($loop->index+1); ?></td>
                                                            <td><?php echo e($item->scope); ?></td>
                                                            <td><?php echo e($item->team); ?></td>
                                                            <td><?php echo e($item->start_date); ?></td>
                                                            <td><?php echo e($item->complete_date); ?></td>
                                                            <td><?php echo e($item->week); ?></td>
                                                            <td><?php echo e($item->remarks); ?></td>
                                                            <td>
                                                                <a data-route="<?php echo e(url('projects/installations/'.$item->id)); ?>" data-csrf="<?php echo e(csrf_token()); ?>" onclick="removeData(this)" class="ms-3" data-bs-toggle="tooltip">
                                                                    <i class="fas fa-trash text-danger" aria-hidden="true"></i>
                                                                </a>
                                                            </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Acceptance -->
                            <div class="card multisteps-form__panel p-3 border-radius-xl bg-white"
                                data-animation="FadeIn">
                                <div class="multisteps-form__content">
                                    <div class="row mt-1">
                                        <div class="col-12" style="text-align: right">
                                            <a class="btn bg-gradient-success" href="#" data-bs-toggle="modal"
                                                data-bs-target="#acceptanceModal">+ Add</a>
                                        </div>
                                        <div class="col-12">
                                            <div class="table-responsive">
                                                <table class="table table-flush" id="datatable-search3">
                                                    <thead class="thead-light">
                                                        <tr>
                                                            <th>#</th>
                                                            <th>Details Received</th>
                                                            <th>Acceptance Date</th>
                                                            <th>Type</th>
                                                            <th>Remarks</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $acceptances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($loop->index+1); ?></td>
                                                            <td><?php echo e($item->details_received); ?></td>
                                                            <td><?php echo e($item->acceptance_date); ?></td>
                                                            <td><?php echo e($item->type); ?></td>
                                                            <td><?php echo e($item->remarks); ?></td>
                                                            <td>
                                                                <a data-route="<?php echo e(url('projects/acceptances/'.$item->id)); ?>" data-csrf="<?php echo e(csrf_token()); ?>" onclick="removeData(this)" class="ms-3" data-bs-toggle="tooltip">
                                                                    <i class="fas fa-trash text-danger" aria-hidden="true"></i>
                                                                </a>
                                                            </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Decomm Materials -->
                            <div class="card multisteps-form__panel p-3 border-radius-xl bg-white"
                                data-animation="FadeIn">
                                <div class="multisteps-form__content">
                                    <div class="row mt-1">
                                        <div class="col-12" style="text-align: right">
                                            <a class="btn bg-gradient-success" href="#" data-bs-toggle="modal"
                                                data-bs-target="#decommModal">+ Add</a>
                                        </div>
                                        <div class="col-12">
                                            <div class="table-responsive">
                                                <table class="table table-flush" id="datatable-search4">
                                                    <thead class="thead-light">
                                                        <tr>
                                                            <th>#</th>
                                                            <th>Decomm Submission Date</th>
                                                            <th>Status</th>
                                                            <th>Remarks</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $decomms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($loop->index+1); ?></td>
                                                            <td><?php echo e($item->submission_date); ?></td>
                                                            <td><?php echo e($item->status); ?></td>
                                                            <td><?php echo e($item->remarks); ?></td>
                                                            <td>
                                                                <a data-route="<?php echo e(url('projects/decomms/'.$item->id)); ?>" data-csrf="<?php echo e(csrf_token()); ?>" onclick="removeData(this)" class="ms-3" data-bs-toggle="tooltip">
                                                                    <i class="fas fa-trash text-danger" aria-hidden="true"></i>
                                                                </a>
                                                            </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Documentation -->
                            <div class="card multisteps-form__panel p-3 border-radius-xl bg-white"
                                data-animation="FadeIn">
                                <div class="multisteps-form__content">
                                    <div class="row mt-1">
                                        <div class="col-12" style="text-align: right">
                                            <a class="btn bg-gradient-success" href="#" data-bs-toggle="modal"
                                                data-bs-target="#documentationModal">+ Add</a>
                                        </div>
                                        <div class="col-12">
                                            <div class="table-responsive">
                                                <table class="table table-flush" id="datatable-search5">
                                                    <thead class="thead-light">
                                                        <tr>
                                                            <th>#</th>
                                                            <th>Document</th>
                                                            <th>Details Received</th>
                                                            <th>Document Type</th>
                                                            <th>Submission Date</th>
                                                            <th>WCR Date</th>
                                                            <th>WCR Status</th>
                                                            <th>Status</th>
                                                            <th>Remarks</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $documentations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($loop->index+1); ?></td>
                                                            <td>
                                                                <a class="ref-link" href="<?php echo e(asset('storage')); ?>/<?php echo e($item->document_path); ?>" target="_blank">
                                                                    <?php echo e($item->document_name); ?>

                                                                </a>
                                                            </td>
                                                            <td><?php echo e($item->details_received); ?></td>
                                                            <td><?php echo e($item->document_type); ?></td>
                                                            <td><?php echo e($item->submission_date); ?></td>
                                                            <td><?php echo e($item->wcr_date); ?></td>
                                                            <td><?php echo e($item->wcr_status); ?></td>
                                                            <td><?php echo e($item->status); ?></td>
                                                            <td><?php echo e($item->remarks); ?></td>
                                                            <td>
                                                                <a data-route="<?php echo e(url('projects/documentations/'.$item->id)); ?>" data-csrf="<?php echo e(csrf_token()); ?>" onclick="removeData(this)" class="ms-3" data-bs-toggle="tooltip">
                                                                    <i class="fas fa-trash text-danger" aria-hidden="true"></i>
                                                                </a>
                                                            </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Material Modal -->
    <div class="modal fade" id="materialModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalMessageTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <form id="materials">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="materialModalLabel">Add Material</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="col-form-label">Collection Date:</label>
                            <input type="date" name="collection_date" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">Collected By:</label>
                            <input type="text" name="collected_by" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">Remarks:</label>
                            <textarea name="remarks" rows="3" class="form-control"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn bg-gradient-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Installation Modal -->
    <div class="modal fade" id="installationModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalMessageTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <form id="installation">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="materialModalLabel">Add Installation</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="col-form-label">Scope:</label>
                            <input type="text" name="scope" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">Team:</label>
                            <input type="text" name="team" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">Start Date:</label>
                            <input type="date" name="start_date" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">Complete Date:</label>
                            <input type="date" name="complete_date" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">Week:</label>
                            <input type="number" name="week" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">Remarks:</label>
                            <textarea name="remarks" rows="3" class="form-control"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn bg-gradient-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Acceptance Modal -->
    <div class="modal fade" id="acceptanceModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalMessageTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <form id="acceptance">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="materialModalLabel">Add Acceptance</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="col-form-label">Details Received:</label>
                            <input type="text" name="details_received" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">Acceptance Date:</label>
                            <input type="date" name="acceptance_date" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">Type:</label>
                            <input type="text" name="type" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">Remarks:</label>
                            <textarea name="remarks" rows="3" class="form-control"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn bg-gradient-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Decomm Modal -->
    <div class="modal fade" id="decommModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalMessageTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <form id="decomm">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="materialModalLabel">Add Decomm Materials</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="col-form-label">Submission Date:</label>
                            <input type="date" name="submission_date" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">Status:</label>
                            <input type="text" name="status" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">Remarks:</label>
                            <textarea name="remarks" rows="3" class="form-control"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn bg-gradient-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Documentation Modal -->
    <div class="modal fade" id="documentationModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalMessageTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <form id="documentation" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="materialModalLabel">Add Decomm Materials</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="col-form-label">Document:</label>
                            <input type="file" name="document" id="document" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">Details Received:</label>
                            <input type="text" name="details_received" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">Document Type:</label>
                            <input type="text" name="document_type" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">Submission Date:</label>
                            <input type="date" name="submission_date" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">WCR Date:</label>
                            <input type="date" name="wcr_date" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">WCR Status:</label>
                            <input type="text" name="wcr_status" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">Status:</label>
                            <input type="text" name="status" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">Remarks:</label>
                            <textarea name="remarks" rows="3" class="form-control"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn bg-gradient-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagespecificscripts'); ?>
    <script src="<?php echo e(asset('assets/js/plugins/multistep-form.js')); ?>"></script>
    <script>
        const dataTableSearch = new simpleDatatables.DataTable("#datatable-search", {
            searchable: false,
            paging: false,
            sortable: false
        });

        const dataTableSearch2 = new simpleDatatables.DataTable("#datatable-search2", {
            searchable: false,
            paging: false,
            sortable: false
        });

        const dataTableSearch3 = new simpleDatatables.DataTable("#datatable-search3", {
            searchable: false,
            paging: false,
            sortable: false
        });

        const dataTableSearch4 = new simpleDatatables.DataTable("#datatable-search4", {
            searchable: false,
            paging: false,
            sortable: false
        });

        const dataTableSearch5 = new simpleDatatables.DataTable("#datatable-search5", {
            searchable: false,
            paging: false,
            sortable: false
        });

        /*---form1 submit---*/
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#project').submit(function(e) {

            const swalCustomButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn bg-gradient-info',
                },
                buttonsStyling: false
            })

            e.preventDefault();
            var form = $(this)[0]; //selector for the current form
            var id = "<?php echo e(Request::segment(2)); ?>";

            //if form validation passed
            if (form.checkValidity() === true) {
                
                //submit to backend
                var formData = new FormData(this);
                formData.append("_method", "PUT");

                $.ajax({
                    // url: "<?php echo e(url('projects/' . $project->id)); ?>",
                    url: ROUTE.PROJECT.PROJECTS + '/<?php echo e($project->id); ?>',
                    type: "POST",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        console.log("success");
                        swalCustomButtons.fire({
                            icon: 'success',
                            position: 'center',
                            type: 'success',
                            title: 'Data Update Successfully!',
                            showButton: true,
                        })
                        setTimeout(function() {
                            window.location = "/projects";
                        }, 1500);
                    },
                    error: function(error) {
                        console.log("error");
                        Swal.fire(
                            'Error!',
                            "Failed! Please try again.",
                            'error'
                        )
                    }
                });
            }
        });

        $('#materials').submit(function(e) {

            const swalCustomButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn bg-gradient-info',
                },
                buttonsStyling: false
            })

            e.preventDefault();
            var form = $(this)[0]; //selector for the current form
            var id = "<?php echo e(Request::segment(2)); ?>";

            //if form validation passed
            if (form.checkValidity() === true) {
                
                //submit to backend
                var formData = new FormData(this);

                $.ajax({
                    // url: "<?php echo e(url('projects/' . $project->id)); ?>",
                    url: ROUTE.PROJECT.PROJECTS + '/<?php echo e($project->id); ?>/materials',
                    type: "POST",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        console.log("success");
                        swalCustomButtons.fire({
                            icon: 'success',
                            position: 'center',
                            type: 'success',
                            title: 'Materials Added!',
                            showButton: true,
                        })
                        setTimeout(function() {
                            window.location.reload();
                        }, 1500);
                    },
                    error: function(error) {
                        console.log("error");
                        Swal.fire(
                            'Error!',
                            "Failed! Please try again.",
                            'error'
                        )
                    }
                });
            }
        });

        $('#installation').submit(function(e) {

            const swalCustomButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn bg-gradient-info',
                },
                buttonsStyling: false
            })

            e.preventDefault();
            var form = $(this)[0]; //selector for the current form
            var id = "<?php echo e(Request::segment(2)); ?>";

            //if form validation passed
            if (form.checkValidity() === true) {
                
                //submit to backend
                var formData = new FormData(this);

                $.ajax({
                    // url: "<?php echo e(url('projects/' . $project->id)); ?>",
                    url: ROUTE.PROJECT.PROJECTS + '/<?php echo e($project->id); ?>/installations',
                    type: "POST",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        console.log("success");
                        swalCustomButtons.fire({
                            icon: 'success',
                            position: 'center',
                            type: 'success',
                            title: 'Installations Added!',
                            showButton: true,
                        })
                        setTimeout(function() {
                            window.location.reload();
                        }, 1500);
                    },
                    error: function(error) {
                        console.log("error");
                        Swal.fire(
                            'Error!',
                            "Failed! Please try again.",
                            'error'
                        )
                    }
                });
            }
        });

        $('#acceptance').submit(function(e) {

            const swalCustomButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn bg-gradient-info',
                },
                buttonsStyling: false
            })

            e.preventDefault();
            var form = $(this)[0]; //selector for the current form
            var id = "<?php echo e(Request::segment(2)); ?>";

            //if form validation passed
            if (form.checkValidity() === true) {
                
                //submit to backend
                var formData = new FormData(this);

                $.ajax({
                    // url: "<?php echo e(url('projects/' . $project->id)); ?>",
                    url: ROUTE.PROJECT.PROJECTS + '/<?php echo e($project->id); ?>/acceptances',
                    type: "POST",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        console.log("success");
                        swalCustomButtons.fire({
                            icon: 'success',
                            position: 'center',
                            type: 'success',
                            title: 'Acceptances Added!',
                            showButton: true,
                        })
                        setTimeout(function() {
                            window.location.reload();
                        }, 1500);
                    },
                    error: function(error) {
                        console.log("error");
                        Swal.fire(
                            'Error!',
                            "Failed! Please try again.",
                            'error'
                        )
                    }
                });
            }
        });

        $('#decomm').submit(function(e) {

            const swalCustomButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn bg-gradient-info',
                },
                buttonsStyling: false
            })

            e.preventDefault();
            var form = $(this)[0]; //selector for the current form
            var id = "<?php echo e(Request::segment(2)); ?>";

            //if form validation passed
            if (form.checkValidity() === true) {
                
                //submit to backend
                var formData = new FormData(this);

                $.ajax({
                    // url: "<?php echo e(url('projects/' . $project->id)); ?>",
                    url: ROUTE.PROJECT.PROJECTS + '/<?php echo e($project->id); ?>/decomms',
                    type: "POST",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        console.log("success");
                        swalCustomButtons.fire({
                            icon: 'success',
                            position: 'center',
                            type: 'success',
                            title: 'Decomm Materials Added!',
                            showButton: true,
                        })
                        setTimeout(function() {
                            window.location.reload();
                        }, 1500);
                    },
                    error: function(error) {
                        console.log("error");
                        Swal.fire(
                            'Error!',
                            "Failed! Please try again.",
                            'error'
                        )
                    }
                });
            }
        });

        $('#documentation').submit(function(e) {

            const swalCustomButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn bg-gradient-info',
                },
                buttonsStyling: false
            })

            e.preventDefault();
            var form = $(this)[0]; //selector for the current form
            var id = "<?php echo e(Request::segment(2)); ?>";

            //if form validation passed
            if (form.checkValidity() === true) {
                
                //submit to backend
                var formData = new FormData(this);

                $.ajax({
                    // url: "<?php echo e(url('projects/' . $project->id)); ?>",
                    url: ROUTE.PROJECT.PROJECTS + '/<?php echo e($project->id); ?>/documentations',
                    type: "POST",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        console.log("success");
                        swalCustomButtons.fire({
                            icon: 'success',
                            position: 'center',
                            type: 'success',
                            title: 'Documentations Added!',
                            showButton: true,
                        })
                        setTimeout(function() {
                            window.location.reload();
                        }, 1500);
                    },
                    error: function(error) {
                        console.log("error");
                        Swal.fire(
                            'Error!',
                            "Failed! Please try again.",
                            'error'
                        )
                    }
                });
            }
        });


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Codligence\Downloads\GitHub\tritosys-pm-web\resources\views/project/edit_project.blade.php ENDPATH**/ ?>